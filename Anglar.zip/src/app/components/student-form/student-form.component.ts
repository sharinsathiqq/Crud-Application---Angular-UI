import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {
  studentForm: FormGroup;
  selectedFile: File | null = null;
  imageSrc: string | ArrayBuffer | null = null;
  

  constructor(private fb: FormBuilder, private http: HttpClient, private route: ActivatedRoute, private router: Router) {
    this.studentForm = this.fb.group({
      name: ['', Validators.required],
      emailID: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', Validators.required],
      dob: ['', Validators.required],
      departmentId: ['', Validators.required],
      file: [null, Validators.required]

    });
  }

  ngOnInit(): void {
    // Initialization already done in the constructor
  }

  get f() { return this.studentForm.controls; } // Accessing form controls

  onSubmit() {
  //  if (this.studentForm.invalid) {
  //     console.log("invalid");
  //     return;
  //   }

    const formData = new FormData();
    formData.append('name', this.f['name'].value);
    formData.append('emailID', this.f['emailID'].value);
    formData.append('phoneNumber', this.f['phoneNumber'].value);
    formData.append('dob', this.f['dob'].value);
    formData.append('departmentId', this.f['departmentId'].value);
    if (this.selectedFile) {
      formData.append('file', this.selectedFile);
  
    }
    
    this.http.post<any>('http://localhost:32167/api/student', formData).subscribe({
      next: response => {
        console.log('Response:', response);
        this.router.navigate(['/students']);
      },

      error: error => {
        console.error('Error:', error);
      }
    });
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];
    if (this.selectedFile) {
      const reader = new FileReader();
      
      reader.onload = (e: ProgressEvent<FileReader>) => {
        this.imageSrc = e.target?.result as string | ArrayBuffer | null;
      };
      
      reader.readAsDataURL(this.selectedFile);
    }
  }
}
